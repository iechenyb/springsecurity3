package com.kiiik.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import com.kiiik.pub.Contants;


@Component
public class ReadProductUtils {
	Log log = LogFactory.getLog(getClass());
	/**
	 * 初始化中文名与品种关系
	 * @author iechenyb
	 * @param codeFile
	 * @throws IOException
	 */
	//
	public void initProductCodeChineseNameMap(File codeFile){
		try{
			Document doc = Jsoup.parse(codeFile, "utf-8");
			Elements pcs = doc.select("product");
			for(int i=0;i<pcs.size();i++){//读取市场信息
					Contants.PRODUCT_CODE_CHINESE_NAME_MAP.put(pcs.get(i).attr("code").toUpperCase()
							,pcs.get(i).attr("chinesename"));
					//初始化夜盘品种
					if(Contants.IS_NINGHT.equals(pcs.get(i).attr("isninght"))){
						Contants.NINGHT_PRODUCT_MAP.put(pcs.get(i).attr("code").toUpperCase(),pcs.get(i).attr("endtime"));
					}
					//初始化中金所品种
					if("CFFEX".equals(pcs.get(i).parentNode().attr("alias"))){
						Contants.CFFEX_PRODUCT_MAP.put(pcs.get(i).attr("code").toUpperCase(), "".intern());
					}
			}
			log.info("中国金融期货交易所品种："+Contants.CFFEX_PRODUCT_MAP);
			log.info("品种中文名映射信息:"+Contants.PRODUCT_CODE_CHINESE_NAME_MAP);
			log.info("夜盘品种信息:"+Contants.NINGHT_PRODUCT_MAP);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
